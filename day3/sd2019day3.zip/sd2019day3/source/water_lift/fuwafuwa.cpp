#include <bits/stdc++.h>
using namespace std;
int t;
unsigned long long a, b, m, n;
int main()
{
    cin >> t;
    while (t--)
    {
        cin >> a >> b >> m >> n;
        int now = (a + n * b) % m;
        int fir = (a + b) % m;
        for (int i = 2; i < n; i++)
        {
            
        }
    }
}